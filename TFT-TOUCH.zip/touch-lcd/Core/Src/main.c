/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"     // 메인 헤더 파일 (핵심 시스템 설정 및 전역 선언 포함)
#include "dma.h"      // DMA 설정용 헤더 (SPI 전송 최적화를 위해 사용)
#include "spi.h"      // SPI 통신 설정용 헤더 (LCD, 터치스크린과 통신)
#include "gpio.h"     // GPIO 설정용 헤더 (버튼, 터치 IRQ 등)

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>         // 문자열 출력과 포맷팅을 위한 표준 라이브러리
#include "graphics.h"      // 그래픽 요소(문자, 도형 등) 출력용 사용자 정의 라이브러리
#include "touch.h"         // 터치 입력 감지 및 처리용 사용자 정의 라이브러리
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* (사용자 타입 정의 필요시 이곳에 작성) */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* (상수 정의 필요시 이곳에 작성) */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* (매크로 정의 필요시 이곳에 작성) */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
SPI_HandleTypeDef hspi2;       // SPI2 핸들 (아마 터치스크린용)
DMA_HandleTypeDef hdma_spi1_tx; // SPI1의 TX 방향 DMA 핸들 (LCD 데이터 전송용)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);  // 시스템 클럭 설정 함수 프로토타입

/* USER CODE BEGIN PFP */
/* (개별 함수 프로토타입 필요시 이곳에 작성) */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* (초기화 전에 수행할 사용자 코드 작성 위치) */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	int16_t x;  // 터치로 읽은 x 좌표 저장용 변수
	int16_t y;  // 터치로 읽은 y 좌표 저장용 변수
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* MCU 주변장치 초기화: 플래시 인터페이스, 시스템 타이머(Systick) 설정 */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* (추가 초기화가 필요한 경우 여기에 작성) */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();  // 시스템 클럭 주파수 설정 (예: 96MHz, 168MHz 등)

  /* USER CODE BEGIN SysInit */
  /* (시스템 초기화 코드 삽입 가능) */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();     // GPIO 포트 초기화 (터치 IRQ 핀, 버튼 등)
  MX_DMA_Init();      // DMA 컨트롤러 초기화 (SPI 통신 가속용)
  MX_SPI4_Init();     // SPI4 초기화 (아마 LCD 제어용 SPI)
  MX_SPI1_Init();     // SPI1 초기화 (터치스크린 데이터용 SPI)

  /* USER CODE BEGIN 2 */
  GraphicsInit();         // LCD 그래픽 드라이버 초기화
  TouchCalibrate();       // 터치스크린 캘리브레이션 (보정 절차 수행)
  GraphicsClear(BLACK);    // LCD 화면 전체를 검정색으로 지움
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	    /* 캘리브레이션된 터치 좌표 읽어오기 */
	    if (TouchGetCalibratedPoint(&x, &y))
	    {
	      /* 좌상단(0,0)부터 너비 120, 높이 15 범위 안에서 터치되면 화면 초기화 */
	      if(x >= 0 && x <= 120 && y >= 0 && y <= 15)
	      {
	        GraphicsClear(BLACK);  // 화면 전체를 다시 검정색으로 초기화
	      }

	      /* 터치 좌표를 문자열로 변환하여 화면 좌상단에 표시 */
	      char buf[20];                  // 좌표 문자열 버퍼
	      sprintf(buf, "%hd %hd", x, y);  // (x,y) 값을 문자열로 변환
	      GraphicsFilledRectangle(0, 0, 120, 15, BLACK);  // 좌표표시 영역을 지움

	      GraphicsLargeString(0, 0, buf, YELLOW);         // 새로운 좌표값 출력

	      /* 터치된 위치에 노란색 점 그리기 (반지름 3) */
	      GraphicsFilledCircle(x, y, 3, YELLOW);
	    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    // (여기에 추가적인 주기적 작업이 들어갈 수 있음)
  }
  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
